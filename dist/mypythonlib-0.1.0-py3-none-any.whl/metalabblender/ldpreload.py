import os

preload():
	os.environ["LD_PRELOAD"] = ""

	!apt remove libtcmalloc-minimal4
	!apt install libtcmalloc-minimal4

	os.environ["LD_PRELOAD"] = "/usr/lib/x86_64-linux-gnu/libtcmalloc_minimal.so.4.3.0"